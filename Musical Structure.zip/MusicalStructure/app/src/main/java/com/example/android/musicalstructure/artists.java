package com.example.android.musicalstructure;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class artists extends AppCompatActivity {
    Button songsButton;
    Button homeButton;
    // Array of strings...
    ListView artistList;
    String artistNames[] = {"Neil Young", "Lana Del Ray", "Sublime", "Greatful Dead", "Bring Me The Horizon",};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.artistlist);
        artistList = (ListView) findViewById(R.id.artistListView);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.listview2, R.id.artist_text_view, artistNames);
        artistList.setAdapter(arrayAdapter);

        songsButton = (Button) findViewById(R.id.song_button);//get id of button 1

        songsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent button1Intent = new Intent(artists.this, songs.class);
                startActivity(button1Intent);
            }
        });

        homeButton = (Button) findViewById(R.id.home_2_button);//get id of button 1

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent button1Intent = new Intent(artists.this, MainActivity.class);
                startActivity(button1Intent);
            }
        });
    }
}