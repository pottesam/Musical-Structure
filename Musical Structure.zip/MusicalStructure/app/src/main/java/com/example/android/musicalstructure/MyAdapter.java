package com.example.android.musicalstructure;

import android.widget.ArrayAdapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;


public class MyAdapter extends ArrayAdapter<songArtist> {
    public MyAdapter(Context context, ArrayList<songArtist> pWords) {
        super(context, 0, pWords);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View songlistView = convertView;

        if (songlistView == null) {
            songlistView = LayoutInflater.from(getContext()).inflate(
                    R.layout.listview2, parent, false);
        }
        songArtist local_songArtist = getItem(position);

        TextView songTextView = songlistView.findViewById(R.id.song_text_view);
        songTextView.setText(local_songArtist.getmSongName());

        TextView artistTextView = songlistView.findViewById(R.id.artist_text_view);
        artistTextView.setText(local_songArtist.getmArtistName());

        return songlistView;
    }
}

